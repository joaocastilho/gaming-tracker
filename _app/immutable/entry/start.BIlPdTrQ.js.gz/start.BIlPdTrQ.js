import{ae as o,ad as r}from"../chunks/B8sdi0JM.js";export{o as load_css,r as start};
