import{ag as o,af as r}from"../chunks/C0aoLO0B.js";export{o as load_css,r as start};
