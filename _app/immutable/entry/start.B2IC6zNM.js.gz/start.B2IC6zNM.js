import{l as o,a as r}from"../chunks/QLxl2k9M.js";export{o as load_css,r as start};
