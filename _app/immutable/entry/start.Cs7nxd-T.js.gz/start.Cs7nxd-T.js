import{l as o,a as r}from"../chunks/CMB-IjVr.js";export{o as load_css,r as start};
