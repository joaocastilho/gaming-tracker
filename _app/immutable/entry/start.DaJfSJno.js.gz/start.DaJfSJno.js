import{af as o,ae as r}from"../chunks/BPnZWyBA.js";export{o as load_css,r as start};
