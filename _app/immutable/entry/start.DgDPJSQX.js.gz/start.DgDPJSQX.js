import{l as o,a as r}from"../chunks/C46EBIAW.js";export{o as load_css,r as start};
