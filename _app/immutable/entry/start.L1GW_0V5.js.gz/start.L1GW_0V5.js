import{ah as o,ag as r}from"../chunks/Cs7tT5NS.js";export{o as load_css,r as start};
