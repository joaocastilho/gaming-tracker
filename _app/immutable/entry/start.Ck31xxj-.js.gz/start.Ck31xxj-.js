import{l as o,a as r}from"../chunks/DsL7w0qx.js";export{o as load_css,r as start};
