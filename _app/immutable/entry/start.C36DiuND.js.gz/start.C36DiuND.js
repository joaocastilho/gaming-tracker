import{af as o,ae as r}from"../chunks/kzUDlPGv.js";export{o as load_css,r as start};
