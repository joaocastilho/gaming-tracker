import{aj as o,ai as r}from"../chunks/CptgJ9kS.js";export{o as load_css,r as start};
