import{ah as o,ag as r}from"../chunks/pUN5vkGX.js";export{o as load_css,r as start};
