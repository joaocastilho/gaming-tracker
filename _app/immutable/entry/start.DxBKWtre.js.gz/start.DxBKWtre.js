import{ah as o,ag as r}from"../chunks/C19o5EUf.js";export{o as load_css,r as start};
