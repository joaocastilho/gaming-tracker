import{l as o,a as r}from"../chunks/m0HAI0VM.js";export{o as load_css,r as start};
