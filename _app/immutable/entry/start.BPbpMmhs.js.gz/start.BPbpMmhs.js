import{aj as o,ai as r}from"../chunks/DDF7mOdE.js";export{o as load_css,r as start};
