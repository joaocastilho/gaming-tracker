import{aj as o,ai as r}from"../chunks/BsHlHPhL.js";export{o as load_css,r as start};
