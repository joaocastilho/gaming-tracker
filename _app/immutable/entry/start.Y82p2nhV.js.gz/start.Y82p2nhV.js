import{aj as o,ai as r}from"../chunks/B0Pu1Hmk.js";export{o as load_css,r as start};
