import{l as o,a as r}from"../chunks/hPbeT8lY.js";export{o as load_css,r as start};
