import{aj as o,ai as r}from"../chunks/C-AFtepM.js";export{o as load_css,r as start};
