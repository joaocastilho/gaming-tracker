import{af as o,ae as r}from"../chunks/Cu7YYGGr.js";export{o as load_css,r as start};
