import{aj as o,ai as r}from"../chunks/BCO-TaVC.js";export{o as load_css,r as start};
