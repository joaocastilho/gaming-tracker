import{E as m}from"../chunks/_M0bbBIV.js";export{m as component};
