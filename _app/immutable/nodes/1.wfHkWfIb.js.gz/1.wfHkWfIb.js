import{E as m}from"../chunks/CLZ4e3Fd.js";export{m as component};
