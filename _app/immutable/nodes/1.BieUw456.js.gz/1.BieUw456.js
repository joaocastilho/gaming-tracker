import{E as m}from"../chunks/m1IQp-DU.js";export{m as component};
