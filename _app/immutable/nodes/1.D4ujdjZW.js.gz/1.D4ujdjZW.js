import{E as m}from"../chunks/DoOekBK_.js";export{m as component};
