import{E as m}from"../chunks/TKkLEgBN.js";export{m as component};
