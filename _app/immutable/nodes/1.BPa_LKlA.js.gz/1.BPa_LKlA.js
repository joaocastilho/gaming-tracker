import{E as m}from"../chunks/C67CES1X.js";export{m as component};
