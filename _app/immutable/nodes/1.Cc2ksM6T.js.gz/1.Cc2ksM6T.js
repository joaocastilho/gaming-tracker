import{E as m}from"../chunks/CUW-Cx8t.js";export{m as component};
