import{E as m}from"../chunks/B6EITREI.js";export{m as component};
