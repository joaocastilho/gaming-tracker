import{E as m}from"../chunks/C4OeS4mU.js";export{m as component};
